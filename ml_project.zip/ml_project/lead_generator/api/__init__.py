"""API module for the Malaysian Lead Generator.

This module provides API endpoints for integrating with external systems.
"""

__version__ = "0.1.0" 