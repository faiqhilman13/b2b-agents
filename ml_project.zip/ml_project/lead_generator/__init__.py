"""
Lead Generator - Malaysian Business Contact Collection Tool

This package provides tools for scraping business contact information from
various Malaysian sources including Yellow Pages, government websites,
university staff directories, and more.
"""

__version__ = "0.1.0" 